from keep_alive import keep_alive
from bot import bot

keep_alive()
bot.run("DEIN_BOT_TOKEN_HIER")